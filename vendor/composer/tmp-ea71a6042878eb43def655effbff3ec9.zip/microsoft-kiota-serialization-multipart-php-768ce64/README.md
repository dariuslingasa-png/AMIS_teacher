# Kiota Multipart Body Serialization Library for PHP

![Build Status](https://github.com/microsoft/kiota-serialization-multipart-php/actions/workflows/pr-validation.yml/badge.svg)
[![Latest Stable Version](https://poser.pugx.org/microsoft/kiota-serialization-multipart/version)](https://packagist.org/packages/microsoft/kiota-serialization-json)
[![Coverage](https://sonarcloud.io/api/project_badges/measure?project=microsoft_kiota-serialization-multipart-php&metric=coverage)](https://sonarcloud.io/dashboard?id=microsoft_kiota-serialization-multipart-php)

The Multipart Serialization Library for PHP is the PHP Multipart serialization library implementation.

A [Kiota](https://github.com/microsoft/kiota) generated project will need a reference to a multipart serialization package to handle multipart body payloads from an API endpoint.

Read more about Kiota [here](https://github.com/microsoft/kiota/blob/main/README.md).

## Using the Kiota JSON Serialization Library for PHP

run `composer require microsoft/kiota-serialization-json` or add the following to your `composer.json` file:

```
{
    "require": {
        // x-release-please-start-version
        "microsoft/kiota-serialization-multipart": "^1.5.2"
        // x-release-please-end
    }
}
```

## Contributing

This project welcomes contributions and suggestions. This project welcomes contributions and suggestions. Issues and pull requests should be made against the [kiota-php](https://github.com/microsoft/kiota-php/) repository.
This repository is only used for releases.

## Trademarks

This project may contain trademarks or logos for projects, products, or services. Authorized use of Microsoft
trademarks or logos is subject to and must follow
[Microsoft's Trademark & Brand Guidelines](https://www.microsoft.com/en-us/legal/intellectualproperty/trademarks/usage/general).
Use of Microsoft trademarks or logos in modified versions of this project must not cause confusion or imply Microsoft sponsorship.
Any use of third-party trademarks or logos are subject to those third-party's policies.
